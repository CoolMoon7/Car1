package Car;

import java.util.List;
import java.util.Scanner;


//Customer search portal
public class CarSearchPortal {
    public static void main(String[] args) {
        // Create an instance of the CarCollection class
        CarCollection carCollection = new CarCollection();

        // Create an instance of the CarSearch class
        CarSearch carSearch = new CarSearch(carCollection.getCars());

        // Create a scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for input
        System.out.println("Enter search term (make, model, type, year, availability): ");
        String searchTerm = scanner.nextLine();

        // Perform the search based on the user input
        List<Car> cars = null;
        switch (searchTerm.toLowerCase()) {
            case "make":
                System.out.println("Enter make: ");
                String make = scanner.nextLine();
                cars = carSearch.searchByMake(make);
                break;
            case "model":
                System.out.println("Enter model: ");
                String model = scanner.nextLine();
                cars = carSearch.searchByModel(model);
                break;
            case "type":
                System.out.println("Enter type: ");
                String type = scanner.nextLine();
                cars = carSearch.searchByType(type);
                break;
            case "year":
                System.out.println("Enter year: ");
                int year = scanner.nextInt();
                cars = carSearch.searchByYear(year);
                break;
            case "availability":
                System.out.println("Enter availability (true or false): ");
                boolean available = scanner.nextBoolean();
                cars = carSearch.searchByAvailability(available);
                break;
            default:
                System.out.println("Invalid search term.");
                break;
        }

        // Print the car details
        if (cars != null && !cars.isEmpty()) {
            for (Car car : cars) {
                System.out.println(car.toString());
            }
        } else {
            System.out.println("No cars found.");
        }

        // Close the scanner object
        scanner.close();
    }
}
