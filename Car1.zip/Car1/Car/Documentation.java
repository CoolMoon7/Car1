package Car;

import java.util.Scanner;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class Documentation {	
	public static void main(String[] args)throws Exception {
		
		Car c1 = new Car("","","",0,0);
		
		Scanner scan = new Scanner(System.in);
		
		
		System.out.println("Please enter your rental car's information:");
		
		System.out.println("Make: ");
		String make = scan.next();
		
		System.out.println("Model: ");
		String model = scan.next();
		
		System.out.println("Type: ");
		String type = scan.next();
		
		System.out.println("Year: ");
		int year = scan.nextInt();
		
		System.out.println("Start Date: ");
		String startDate = scan.next();
		
		System.out.println("End Date: ");
		String endDate = scan.next();
		
		System.out.println("Thank you!");
		
		try {
		XWPFDocument document = new XWPFDocument();
		FileOutputStream out = new FileOutputStream(new File("CarRentalAgreement.docx"));
		
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun header = paragraph.createRun();
		header.setFontSize(20);
		header.setBold(true);
		header.setText("Car Rental Agreement");
		header.addBreak();
		header.addBreak();
		
		XWPFRun carInfoTitle = paragraph.createRun();
		carInfoTitle.setFontSize(14);
		carInfoTitle.setUnderline(UnderlinePatterns.SINGLE);
		carInfoTitle.setText("Car Information");
		carInfoTitle.addBreak();
		
		XWPFRun carInfo = paragraph.createRun();
		carInfo.setText("Make:      " + make);
		carInfo.addBreak();
		carInfo.setText("Model:     " + model);
		carInfo.addBreak();
		carInfo.setText("Type:        " + type);
		carInfo.addBreak();
		carInfo.setText("Year:         " + year);
		carInfo.addBreak();
		carInfo.addBreak();
		
		XWPFRun durationTitle = paragraph.createRun();
		durationTitle.setUnderline(UnderlinePatterns.SINGLE);
		durationTitle.setFontSize(14);
		durationTitle.setText("Rental Duration");
		durationTitle.addBreak();
		
		XWPFRun duration = paragraph.createRun();
		duration.setText("Start Date:   " + startDate);
		duration.addBreak();
		duration.setText("End Date:     " + endDate);
		duration.addBreak();
		duration.addBreak();
		
		XWPFRun customerInfoTitle = paragraph.createRun();
		customerInfoTitle.setUnderline(UnderlinePatterns.SINGLE);
		customerInfoTitle.setFontSize(14);
		customerInfoTitle.setText("Customer Information");
		customerInfoTitle.addBreak();
		
		XWPFRun customerInfo = paragraph.createRun();
		customerInfo.setText("(I still need the customer class)");
		customerInfo.addBreak();
		customerInfo.addBreak();
		
		XWPFRun agreementTitle = paragraph.createRun();
		agreementTitle.setFontSize(14);
		agreementTitle.setUnderline(UnderlinePatterns.SINGLE);
		agreementTitle.setText("Agreement");
		agreementTitle.addBreak();
		
		XWPFRun agreement = paragraph.createRun();
		agreement.setText(" - The customer will have to pay extra for any additional fuel not refilled.");
		agreement.addBreak();
		agreement.setText(" - The vehicle must be returned in the same condition it was in.");
		agreement.addBreak();
		agreement.addBreak();
		
		XWPFRun signature = paragraph.createRun();
		signature.setFontSize(14);
		signature.addBreak();
		signature.setText("Name: ______________      Date: __/__/____");
		document.write(out);
		out.close();
		}catch(Exception e) {
			System.out.println(e);
		}
		System.out.println("document created, saved in Car1 project as CarRentalAgreement.docx");
	}
}
