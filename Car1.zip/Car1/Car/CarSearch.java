package Car;

import java.util.List;
import java.util.stream.Collectors;

public class CarSearch {
    private List<Car> cars;

    public CarSearch(List<Car> cars) {
        this.cars = cars;
    }

    public List<Car> searchByMake(String make) {
        return cars.stream()
                .filter(car -> car.getMake().equalsIgnoreCase(make))
                .collect(Collectors.toList());
    }

    public List<Car> searchByModel(String model) {
        return cars.stream()
                .filter(car -> car.getModel().equalsIgnoreCase(model))
                .collect(Collectors.toList());
    }

    public List<Car> searchByType(String type) {
        return cars.stream()
                .filter(car -> car.getType().equalsIgnoreCase(type))
                .collect(Collectors.toList());
    }

    public List<Car> searchByYear(int year) {
        return cars.stream()
                .filter(car -> car.getYear() == year)
                .collect(Collectors.toList());
    }

    public List<Car> searchByAvailability(boolean available) {
        return cars.stream()
                .filter(car -> car.isAvailable() == available)
                .collect(Collectors.toList());
    }
}

