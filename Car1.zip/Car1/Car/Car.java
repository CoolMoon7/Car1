package Car;

/**
 * Car class constructs a car object to be called by the CarSearchPortal Class
 */

public class Car {
    private String make;
    private String model;
    private String type;
    private int year;
    private double dailyRate;
    private boolean available;

    // Constructors
    //Stores all variable listed below tied to each indivual car object
    public Car(String make, String model, String type, int year, double dailyRate) {
        this.make = make;
        this.model = model;
        this.type = type;
        this.year = year;
        this.dailyRate = dailyRate;
        this.available = true;
    }

    // Getters and setters
    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getDailyRate() {
        return dailyRate;
    }

    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    // Other methods
    public String toString() {
        return make + " " + model + " " + type + "(" + year + ") Available? " + available;
    }
}
