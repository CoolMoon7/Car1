package Car;
/**
 * CarCollection class stores the variables for each car object
 */

import java.util.ArrayList;
import java.util.List;

public class CarCollection {
    private List<Car> cars;

    public CarCollection() {
        cars = new ArrayList<Car>();
        addCars();
    }

    private void addCars() {
        cars.add(new Car("Toyota", "Camry", "Sedan", 2022, 50.0));
        cars.add(new Car("Honda", "Accord", "Sedan", 2021, 50.0));
        cars.add(new Car("Nissan", "Altima", "Sedan", 2020, 50.0));

        cars.add(new Car("Toyota", "Corolla", "Compact", 2022, 40.0));
        cars.add(new Car("Honda", "Civic", "Compact", 2021, 40.0));
        cars.add(new Car("Nissan", "Sentra", "Compact", 2020, 40.0));

        cars.add(new Car("Toyota", "Rav4", "Compact SUV", 2022, 40.0));
        cars.add(new Car("Honda", "CRV", "Compact SUV", 2021, 40.0));
        cars.add(new Car("Nissan", "Rogue", "Compact SUV", 2020, 40.0));

        cars.add(new Car("Toyota", "Sequoia", "Full-Size SUV", 2022, 70.0));
        cars.add(new Car("Honda", "Pilot", "Full-Size SUV", 2021, 70.0));
        cars.add(new Car("Nissan", "Armada", "Full-Size SUV", 2020, 70.0));
    }

    public List<Car> getCars() {
        return cars;
    }

    public void setCars(List<Car> cars) {
        this.cars = cars;
    }
}

