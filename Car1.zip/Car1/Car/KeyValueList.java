package Car;
import java.util.ArrayList;

class KeyValue<K, V>
{
	private K key;
	private V value;
	
	public KeyValue(K key, V value)
	{
		this.key = key;
		this.value = value;
	}
	
	public K getKey() { return key; }
	public V getValue() { return value; }
}

public class KeyValueList<K, V>
{
	private ArrayList<KeyValue<K,V>> list;
	
	public KeyValueList()
	{
		list = new ArrayList<KeyValue<K, V>>();
	}
	
	public void add(KeyValue<K, V> kv)
	{
		list.add(kv);
	}
	
	public V getValue(K key)
	{
		for (KeyValue kv : list)
		{
			if (kv.getKey().equals(key))
			{
				return (V)kv.getValue();
			}
		}
		
		return null;
	}
	
	public void clear()
	{
		list.clear();
	}
}