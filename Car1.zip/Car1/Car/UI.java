package Car;
import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * 
 * example on how to use the class
 * 
 * ===============================
 * UI.create(); // must be called before any other method in this class
 * UI.addLabel("Car year:");
 * UI.addTextField("car year text field");
 * UI.nextLine();
 * UI.pushCentered();
 * UI.addLabel("Car model:");
 * UI.addTextField("car model text field");
 * UI.nextLine();
 * UI.addLabel("Car mileage:");
 * UI.addTextField("car mileage text field");
 * UI.popCentered();
 * UI.nextLine();
 * UI.addButton("Submit", e -> 
 * {
 * 	System.out.println("year: " + UI.getData("car year text field"));
 * 	System.out.println("model: " + UI.getData("car model text field"));
 * 	System.out.println("mileage: " + UI.getData("car mileage text field"));
 * });
 * 
 * @author teddy
 */

public class UI
{
	private static JFrame frame;
	private static JPanel panel;
	private static KeyValueList<String, JComponent> list;
	private static int width = 600;
	private static int height = 500;
	private static boolean is_centered;
	private static int ui_x;
	private static int ui_y;
	private static int ui_w;
	private static int ui_h;
	private static int ui_pad_x;
	private static int ui_pad_y;
	
	/**
	 * creates all things needed
	 */
	public static void create()
	{
		frame = new JFrame();
		panel = new JPanel();
		frame.setSize(width, height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("UI test");
		frame.add(panel);
		
		panel.setLayout(null);
		
		ui_pad_x = 10;
		ui_pad_y = 10;
		ui_x = 0;
		ui_y = 0;
		ui_w = 200;
		ui_h = 25;
		is_centered = false;
		
		list = new KeyValueList<String, JComponent>();
	}
	
	/**
	 * clears all ui components
	 */
	public static void clear()
	{
		panel.removeAll();
		
		ui_pad_x = 10;
		ui_pad_y = 10;
		ui_x = 0;
		ui_y = 0;
		ui_w = 200;
		ui_h = 25;
		is_centered = false;
		
		list.clear();
	}
	
	/**
	 * gets layout with padding and position
	 * @return Dimension containing layout
	 */
	private static Dimension getAutoLayout()
	{
		Dimension dim = new Dimension();
		
		dim.width = ui_x + ui_pad_x;
		dim.height = ui_y + ui_pad_y;
		
		ui_x += ui_w + ui_pad_x;
		
		return dim;
	}
	
	/**
	 * puts all ui on a new line
	 */
	public static void nextLine()
	{
		ui_y += ui_h + ui_pad_y;
		ui_x = is_centered ? width / 2 - ui_w : 0;
	}
	
	/**
	 * adds centering
	 */
	public static void pushCentered()
	{
		ui_x = width / 2 - ui_w;
		is_centered = true;
	}
	
	/**
	 * removes centering
	 */
	public static void popCentered()
	{
		ui_x = 0;
		is_centered = false;
	}
	
	/**
	 * adds a label
	 * @param name name of label
	 */
	public static void addLabel(String name)
	{
		Dimension pos = getAutoLayout();
		
		frame.setVisible(false);
		JLabel label = new JLabel(name);
		label.setBounds(pos.width, pos.height, ui_w, ui_h);
		panel.add(label);
		frame.setVisible(true);
		
		list.add(new KeyValue<String, JComponent>(name, label));
	}
	
	/**
	 * adds a button
	 * @param name name of button
	 * @param event gets called whenever the button is clicked
	 */
	public static void addButton(String name, ActionListener event)
	{
		Dimension pos = getAutoLayout();
		
		frame.setVisible(false);
		JButton button = new JButton(name);
		button.setBounds(pos.width, pos.height, ui_w, ui_h);
		button.addActionListener(event);
		panel.add(button);
		frame.setVisible(true);
		
		list.add(new KeyValue<String, JComponent>(name, button));
	}
	
	/**
	 * adds a text field
	 * @param name name of text field and used for getting data
	 */
	public static void addTextField(String name)
	{
		Dimension pos = getAutoLayout();
		
		frame.setVisible(false);
		JTextField text_field = new JTextField("");
		text_field.setBounds(pos.width, pos.height, ui_w, ui_h);
		panel.add(text_field);
		frame.setVisible(true);
		
		list.add(new KeyValue<String, JComponent>(name, text_field));
	}
	
	/**
	 * 
	 * @param name same name of text field used when calling addTextField
	 * @return String of text field 
	 */
	public static String getData(String name)
	{
		if (list.getValue(name) != null)
		{
			JTextField text = (JTextField)list.getValue(name);
			return text.getText();
		}
		
		return null;
	}
}
